let car = {
  type: "Sedan",
  model: "Camry",
  color: "black"
};

console.log("Type of car:", typeof car); 

car.type = "Toyota";
console.log("Updated car object:", car);

car.wheels = 4;
console.log("Updated car object with wheels:", car);


