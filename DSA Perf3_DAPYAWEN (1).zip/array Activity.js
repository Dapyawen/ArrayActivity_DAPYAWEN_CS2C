let favSingers = ["Arthur Nery", "(Cueshè)", "Shanti Dope"];

console.log("First Singer:", favSingers[0]);

let favNumbers = [3, 08, 01, 10];

let mixedArr = ["string", ["otherarray"], 123, true];

console.log("First item in mixedArr:", mixedArr[0]);
console.log("Second item in mixedArr:", mixedArr[1]);
console.log("Third item in mixedArr:", mixedArr[2]);
console.log("Fourth item in mixedArr:", mixedArr[3]);
